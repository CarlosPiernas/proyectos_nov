/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package Prueba;

import java.io.*;

/**
 *
 * @author Carlos
 */
public class GeneDatos {

    public static void main(String[] args) {
        Citas c = new Citas();
        Clientes cli = new Clientes();
        Facturas f = new Facturas();
        Inventario i = new Inventario();
        Peluqueras p = new Peluqueras();
        Servicios s = new Servicios();
    }
}
